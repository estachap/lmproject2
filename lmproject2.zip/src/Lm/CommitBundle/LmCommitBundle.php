<?php

namespace Lm\CommitBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class LmCommitBundle extends Bundle
{
}
