<?php

namespace Lm\CommitBundle\Model;

use Lm\CommitBundle\Model\om\BaseFilePeer;

class FilePeer extends BaseFilePeer
{
}
