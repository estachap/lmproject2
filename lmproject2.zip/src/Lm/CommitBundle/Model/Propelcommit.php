<?php

namespace Lm\CommitBundle\Model;

use Lm\CommitBundle\Model\om\BasePropelcommit;

class Propelcommit extends BasePropelcommit
{
}
