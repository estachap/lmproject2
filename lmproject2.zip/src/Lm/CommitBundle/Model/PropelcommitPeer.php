<?php

namespace Lm\CommitBundle\Model;

use Lm\CommitBundle\Model\om\BasePropelcommitPeer;

class PropelcommitPeer extends BasePropelcommitPeer
{
}
