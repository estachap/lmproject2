<?php

namespace Lm\CommitBundle\Model;

use Lm\CommitBundle\Model\om\BasePropelcommitQuery;

class PropelcommitQuery extends BasePropelcommitQuery
{
}
