<?php

namespace Lm\CommitBundle\Model;

use Lm\CommitBundle\Model\om\BaseAuthor;

class Author extends BaseAuthor
{
}
