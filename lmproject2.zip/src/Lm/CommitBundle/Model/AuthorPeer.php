<?php

namespace Lm\CommitBundle\Model;

use Lm\CommitBundle\Model\om\BaseAuthorPeer;

class AuthorPeer extends BaseAuthorPeer
{
}
